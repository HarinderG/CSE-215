/*
	Harinder Gakhal
	2/19/19
	CSE 215
*/

//libraries
#include <stdio.h>
#include <string.h>
#include <ctype.h>

//functions
void filter(char *arr);
void print (char *str);
void setIntersect(char *str1, char *str2, char *str3);
void setUnion(char *str1, char *str2, char *str3);
void setComp(char *str1, char *str2, char *str3);